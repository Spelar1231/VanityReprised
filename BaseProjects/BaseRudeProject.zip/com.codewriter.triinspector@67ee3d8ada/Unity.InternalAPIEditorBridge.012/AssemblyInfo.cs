﻿using System.Runtime.CompilerServices;

[assembly: InternalsVisibleTo("TriInspector.Editor")]
[assembly: InternalsVisibleTo("TriInspector.Editor.Extras")]