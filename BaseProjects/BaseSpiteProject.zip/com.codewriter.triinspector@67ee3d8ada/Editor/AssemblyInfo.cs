﻿using System.Runtime.CompilerServices;

[assembly: InternalsVisibleTo("TriInspector.Editor.Extras")]
[assembly: InternalsVisibleTo("TriInspector.Editor.Samples")]
[assembly: InternalsVisibleTo("TriInspector.Editor.Integrations.Odin")]