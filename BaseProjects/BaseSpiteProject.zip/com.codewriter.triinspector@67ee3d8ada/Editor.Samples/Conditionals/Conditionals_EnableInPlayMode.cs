﻿using TriInspector;
using UnityEngine;

public class Conditionals_EnableInPlayMode : ScriptableObject
{
    [EnableInPlayMode]
    public float val;
}