﻿namespace TriInspector
{
    public static class TriDrawerOrder
    {
        public const int System = -9999;
        public const int Inspector = -2000;
        public const int Validator = -1500;
        public const int Decorator = -1000;
        public const int Drawer = 0;
        public const int Fallback = 9999;
    }
}