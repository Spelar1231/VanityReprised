﻿using TriInspector;
using UnityEngine;

public class Conditionals_EnableInEditMode : ScriptableObject
{
    [EnableInEditMode]
    public float val;
}