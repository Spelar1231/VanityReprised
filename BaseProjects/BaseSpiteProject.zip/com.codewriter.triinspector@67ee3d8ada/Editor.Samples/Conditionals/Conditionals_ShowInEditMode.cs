﻿using TriInspector;
using UnityEngine;

public class Conditionals_ShowInEditMode : ScriptableObject
{
    [ShowInEditMode]
    public float val;
}