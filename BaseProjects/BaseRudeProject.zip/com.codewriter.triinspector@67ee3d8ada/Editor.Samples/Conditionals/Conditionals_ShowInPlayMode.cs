﻿using TriInspector;
using UnityEngine;

public class Conditionals_ShowInPlayMode : ScriptableObject
{
    [ShowInPlayMode]
    public float val;
}