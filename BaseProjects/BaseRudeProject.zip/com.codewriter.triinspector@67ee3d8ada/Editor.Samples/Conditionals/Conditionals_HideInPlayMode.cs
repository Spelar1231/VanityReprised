﻿using TriInspector;
using UnityEngine;

public class Conditionals_HideInPlayMode : ScriptableObject
{
    [HideInPlayMode]
    public float val;
}