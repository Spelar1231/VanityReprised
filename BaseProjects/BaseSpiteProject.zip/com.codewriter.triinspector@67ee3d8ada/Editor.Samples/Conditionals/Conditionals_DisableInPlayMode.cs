﻿using TriInspector;
using UnityEngine;

public class Conditionals_DisableInPlayMode : ScriptableObject
{
    [DisableInPlayMode]
    public float val;
}