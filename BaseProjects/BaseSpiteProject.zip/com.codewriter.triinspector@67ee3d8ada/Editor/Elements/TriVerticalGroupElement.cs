﻿namespace TriInspector.Elements
{
    public class TriVerticalGroupElement : TriPropertyCollectionBaseElement
    {
    }
}