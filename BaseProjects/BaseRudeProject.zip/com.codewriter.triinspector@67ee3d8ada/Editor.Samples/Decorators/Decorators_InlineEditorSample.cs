﻿using TriInspector;
using UnityEngine;

public class Decorators_InlineEditorSample : ScriptableObject
{
    [InlineEditor]
    public Material mat;
}