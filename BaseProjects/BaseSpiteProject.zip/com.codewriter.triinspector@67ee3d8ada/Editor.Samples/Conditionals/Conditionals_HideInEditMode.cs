﻿using TriInspector;
using UnityEngine;

public class Conditionals_HideInEditMode : ScriptableObject
{
    [HideInEditMode]
    public float val;
}