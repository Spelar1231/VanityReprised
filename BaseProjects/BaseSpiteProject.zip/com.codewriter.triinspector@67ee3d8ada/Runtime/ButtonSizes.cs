namespace TriInspector
{
    public enum ButtonSizes
    {
        Small = 0,
        Medium = 22,
        Large = 32,
        Gigantic = 62,
    }
}