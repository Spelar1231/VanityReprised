﻿using TriInspector;
using UnityEngine;

public class Conditionals_DisableInEditMode : ScriptableObject
{
    [DisableInEditMode]
    public float val;
}